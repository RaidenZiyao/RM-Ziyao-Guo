﻿const generatedBibEntries = {
    "author2020ai": {
        "author": "Author, Name",
        "doi": "10.1038/s41598-020-79193-2",
        "journal": "Scientific Reports",
        "number": "1",
        "pages": "79193",
        "title": "AI-based Models for Predicting Dengue Outbreaks",
        "type": "article",
        "url": "https://doi.org/10.1038/s41598-020-79193-2",
        "volume": "10",
        "year": "2020"
    },
    "author2021early": {
        "author": "Author, Name",
        "journal": "Journal Name",
        "number": "2",
        "pages": "771--780",
        "title": "Early Prediction of Dengue using Machine Learning",
        "type": "article",
        "volume": "14",
        "year": "2021"
    },
    "author2021trends": {
        "author": "Author, Name",
        "journal": "Journal Name",
        "number": "2",
        "pages": "771--780",
        "title": "Using Machine Learning Techniques to Detect Early Trends in Epidemics",
        "type": "article",
        "volume": "14",
        "year": "2021"
    },
    "author2022using": {
        "author": "Author, Name",
        "doi": "10.1186/s13073-022-01034-w",
        "journal": "Genome Medicine",
        "number": "1",
        "pages": "34",
        "title": "Using Machine Learning to Predict Dengue Fever Outbreaks",
        "type": "article",
        "url": "https://doi.org/10.1186/s13073-022-01034-w",
        "volume": "14",
        "year": "2022"
    },
    "davi2019severe": {
        "author": "Davi, Cristina and Maia, P D and Kutz, J Nathan",
        "journal": "IEEE Transactions on Biomedical Engineering",
        "number": "10",
        "pages": "2861--2868",
        "publisher": "IEEE",
        "title": "Severe Dengue Prognosis Using Human Genome Data and Machine Learning",
        "type": "article",
        "url": "https://ieeexplore.ieee.org/document/8703845",
        "volume": "66",
        "year": "2019"
    },
    "iqbal2019machine": {
        "author": "Iqbal, Naiyar and Islam, Mohammad",
        "doi": "10.31449/inf.v43i1.1548",
        "journal": "Informatica",
        "number": "1",
        "pages": "363--371",
        "title": "Machine Learning for Dengue Outbreak Prediction: A Performance Evaluation of Different Prominent Classifiers",
        "type": "article",
        "url": "https://doi.org/10.31449/inf.v43i1.1548",
        "volume": "43",
        "year": "2019"
    },
    "mak2021predictive": {
        "author": "Author, Name",
        "doi": "10.1186/s12911-021-01493-y",
        "journal": "BMC Medical Informatics and Decision Making",
        "number": "1",
        "pages": "1--12",
        "title": "Predictive Models for Dengue using Machine Learning Techniques",
        "type": "article",
        "url": "https://doi.org/10.1186/s12911-021-01493-y",
        "volume": "21",
        "year": "2021"
    },
    "raja2019artificial": {
        "author": "Raja, Dhesi Baha and Mallol, Rainier and Ting, Choo Yee and Kamaludin, Fadzilah and Ahmad, Rohani and Ismail, Suzilah and Jayaraj, Vivek Jason and Sundram, Bala Murali",
        "journal": "Malaysian Journal of Public Health Medicine",
        "number": "2",
        "pages": "103--108",
        "publisher": "Public Health Medicine Specialist",
        "title": "Artificial Intelligence Model as Predictor for Dengue Outbreaks",
        "type": "article",
        "url": "https://m-jem.com",
        "volume": "19",
        "year": "2019"
    },
    "sarma2020dengue": {
        "author": "Sarma, Dhiman and Bhuiya, Md Abdul Motaleb and Hossain, Sohrab and Saha, Ishita and Mittra, Tanni and Chakma, Ravina",
        "booktitle": "2020 IEEE 8th R10 Humanitarian Technology Conference (R10-HTC)",
        "organization": "IEEE",
        "pages": "1--6",
        "title": "Dengue Prediction using Machine Learning Algorithms",
        "type": "inproceedings",
        "url": "https://ieeexplore.ieee.org/document/9357035",
        "year": "2020"
    }
};